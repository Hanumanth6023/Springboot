package com.company;

import java.util.Scanner;

public class Sum {
    int a,b,c;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a value");
    a = sc.nextInt();
}
