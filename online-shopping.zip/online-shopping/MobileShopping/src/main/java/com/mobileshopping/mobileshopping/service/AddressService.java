package com.mobileshopping.mobileshopping.service;

import com.mobileshopping.mobileshopping.model.Address;

public interface AddressService {

    boolean saveAddress(Address address);

    Address findAddressByBilling(boolean billing);

}
