package com.mobileshopping.mobileshopping.service;


import com.mobileshopping.mobileshopping.model.User;

public interface UserService {

    boolean saveUser(User user);

    User findUserByEmail(String email);

}

