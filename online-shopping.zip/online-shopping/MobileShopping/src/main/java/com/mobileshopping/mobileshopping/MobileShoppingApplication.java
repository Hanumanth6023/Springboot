package com.mobileshopping.mobileshopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileShoppingApplication {

    public static void main(String[] args) {
        SpringApplication.run(MobileShoppingApplication.class, args);
    }

}
