package com.mobileshopping.mobileshopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileShoppingApplicationTests {

    @Test
    void contextLoads() {
    }

}
